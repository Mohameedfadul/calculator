1) Install Android Studio (developer.android.com/studio)
2) File > Open > choose the CalculatorApp folder, wait for Gradle sync
3) Build > Build APK(s)  (or Build > Generate Signed Bundle / APK for release)
4) The APK is at app/build/outputs/apk/debug/app-debug.apk
To change the calculator, edit app/src/main/assets/index.html
